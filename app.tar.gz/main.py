import flet as ft

def main(page: ft.Page):
    page.title = "DEVGLOYD"
    
    # 1. Switch to DARK mode
    page.theme_mode = ft.ThemeMode.DARK 
    # 2. Force background to pure black
    page.bgcolor = ft.Colors.BLACK 
    
    # --- ADD THIS LINE FOR THE ICON ---
    # This looks for "favicon.png" inside your /assets folder
    page.window_icon = "favicon.png" 
    
    page.padding = 0
    page.spacing = 0
    page.scroll = ft.ScrollMode.ALWAYS

    # --- References for the Form ---
    email_ref = ft.Ref[ft.TextField]()
    msg_ref = ft.Ref[ft.TextField]()

    # --- Form Logic ---
    def send_inquiry(e):
        target_email = "enffdfdf@gmail.com" 
        user_email = email_ref.current.value
        user_msg = msg_ref.current.value
        subject = f"Website Inquiry from {user_email}"
        page.launch_url(f"mailto:{target_email}?subject={subject}&body={user_msg}")
        page.dialog.open = False
        page.update()

    def close_dlg(e):
        page.dialog.open = False
        page.update()

    def show_dialog(e):
        title_text = e.control.data
        if title_text == "CONTACT US":
            content = ft.Container(
                content=ft.Column([
                    ft.Text("Inquiry Form", size=20, weight="bold", color=ft.Colors.WHITE),
                    ft.TextField(ref=email_ref, label="Your Email", width=700),
                    ft.TextField(ref=msg_ref, label="Message", multiline=True, min_lines=5, width=700),
                    ft.Button("Send Inquiry", bgcolor="#373e4e", color="white", on_click=send_inquiry)
                ], tight=True, spacing=10),
                width=800,
                padding=20
            )
        else:
            content = ft.Container(
                height=400,
                width=800,
                bgcolor=ft.Colors.BLACK,
                border_radius=15,
                border=ft.Border.all(1, ft.Colors.WHITE),
                alignment=ft.alignment.Alignment(0, 0),
                content=ft.Text(f"Content for {title_text}", color=ft.Colors.WHITE),
            )
        dlg = ft.AlertDialog(
            title=ft.Text(title_text, color=ft.Colors.WHITE),
            content=content,
            actions=[ft.TextButton("Close", on_click=close_dlg)]
        )
        page.dialog = dlg
        page.overlay.append(dlg)
        dlg.open = True
        page.update()

    # --- UI Helpers ---
    def create_section_container(title, content_list):
        return ft.Stack([
            ft.Container(
                width=1000,
                bgcolor=ft.Colors.BLACK,
                margin=ft.Margin.only(top=10, bottom=20),
                border_radius=20,
                border=ft.Border.all(1, ft.Colors.LIGHT_BLUE_100),
                padding=ft.Padding.only(top=30, left=20, right=20, bottom=20),
                content=ft.Column(content_list, spacing=10)
            ),
            ft.Container(
                content=ft.Text(title, size=14, weight="bold", color=ft.Colors.WHITE),
                bgcolor=ft.Colors.BLACK,
                padding=ft.Padding.symmetric(horizontal=10),
                left=40,
                top=0,
            ),
        ])

    def placeholder_item(label, img_src):
        return ft.Column([
            ft.Container(
                width=100, 
                height=100, 
                border_radius=10,
                content=ft.Image(src=img_src, fit="contain"), 
            ),
            ft.Column([
                ft.Text(f"{label}", weight="bold", color=ft.Colors.WHITE, size=14),
                ft.Text("Description placeholder text goes here.", 
                        color=ft.Colors.WHITE70, 
                        size=12, 
                        text_align=ft.TextAlign.CENTER),
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=5)
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER)

    # --- Header UI ---
    logo_frame = ft.Container(
        content=ft.Column(
            controls=[
                ft.Image(src="BLUE_EARTH.gif", height=350, fit="cover"),
                ft.Image(src="LOGO_AI_TEXT.png", width=400, fit="contain"),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=20,
        ),
        bgcolor=ft.Colors.BLACK,
        width=float("inf"),
        alignment=ft.alignment.Alignment.CENTER,
        padding=ft.Padding.only(left=20, top=50, right=20, bottom=40)
    )

    # --- Core Mission Content ---
    mission_content = [
        ft.ResponsiveRow([
            ft.Container(
                content=ft.Image(src="ABOUT.PNG", height=350, fit="contain"),
                col={"sm": 12, "md": 4},
            ),
            ft.Container(
                content=ft.Text(
                    spans=[
                        ft.TextSpan(
                            text="We specialize in developing bespoke web solutions tailored to the unique operational requirements of your business...\n\n",
                            style=ft.TextStyle(color=ft.Colors.GREY_500)
                        ),
                        ft.TextSpan(
                            text="Adapting to the Digital Evolution\n\n",
                            style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD)
                        ),
                        ft.TextSpan(
                            text="The global commerce landscape is shifting toward a 'consumer-first' philosophy...\n\n",
                            style=ft.TextStyle(color=ft.Colors.GREY_500)
                        ),
                        ft.TextSpan(
                            text="Strategic Automation & E-commerce\n\n",
                            style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD)
                        ),
                        ft.TextSpan(
                            text="We empower enterprises to move beyond manual processes through advanced technological automation.",
                            style=ft.TextStyle(color=ft.Colors.GREY_500)
                        ),
                    ],
                    size=16,
                    text_align=ft.TextAlign.JUSTIFY
                ),
                col={"sm": 12, "md": 8},
                padding=10,
            ),
        ], vertical_alignment=ft.CrossAxisAlignment.CENTER)
    ]

    # --- Services Content ---
    services_content = [
        ft.ResponsiveRow([
            ft.Container(
                content=ft.Image(src="APPS.PNG", height=350, fit="contain"),
                col={"sm": 12, "md": 4},
            ),
            ft.Container(
                content=ft.Text(
                    spans=[
                        ft.TextSpan("Mobile Apps \n\n", style=ft.TextStyle(color=ft.Colors.WHITE, weight="bold")),
                        ft.TextSpan("Stop following the market and start leading it from your customers' pockets.", style=ft.TextStyle(color=ft.Colors.GREY_500)),
                    ],
                    size=16, text_align=ft.TextAlign.JUSTIFY
                ),
                col={"sm": 12, "md": 8}, padding=10,
            ),
        ], vertical_alignment=ft.CrossAxisAlignment.CENTER),
        ft.Divider(height=40, color=ft.Colors.GREY_800),
        ft.ResponsiveRow([
            ft.Container(
                content=ft.Image(src="WEB.PNG", height=350, fit="contain"),
                col={"sm": 12, "md": 4},
            ),
            ft.Container(
                content=ft.Text(
                    spans=[
                        ft.TextSpan("Web & Progressive Web Apps (PWA) \n\n", style=ft.TextStyle(color=ft.Colors.WHITE, weight="bold")),
                        ft.TextSpan("Why choose between a website and an app when you can have the best of both?", style=ft.TextStyle(color=ft.Colors.GREY_500)),
                    ],
                    size=16, text_align=ft.TextAlign.JUSTIFY
                ),
                col={"sm": 12, "md": 8}, padding=10,
            ),
        ], vertical_alignment=ft.CrossAxisAlignment.CENTER),
    ]

    # --- About Us Section ---
    about_section = ft.Stack([
        ft.Container(
            width=1000,
            bgcolor=ft.Colors.BLACK,
            margin=ft.Margin.only(top=10),
            border_radius=20,
            border=ft.Border.all(1, ft.Colors.LIGHT_BLUE_100),
            padding=ft.Padding.only(top=40, left=20, right=20, bottom=40),
            content=ft.ResponsiveRow([
                ft.Container(content=placeholder_item("Team Member 1", "US.PNG"), col={"xs": 12, "sm": 4}),
                ft.Container(content=placeholder_item("Team Member 2", "US.PNG"), col={"xs": 12, "sm": 4}),
                ft.Container(content=placeholder_item("Team Member 3", "US.PNG"), col={"xs": 12, "sm": 4}),
            ], alignment=ft.MainAxisAlignment.CENTER, run_spacing=30)
        ),
        ft.Container(
            content=ft.Text(" ABOUT US ", size=14, weight="bold", color=ft.Colors.WHITE),
            bgcolor=ft.Colors.BLACK,
            padding=ft.Padding.symmetric(horizontal=10),
            left=40,
            top=0,
        ),
    ], margin=ft.Margin.only(top=40))

    # --- Contact Us Section ---
    contact_section = ft.Stack([
        ft.Container(
            width=1000,
            bgcolor=ft.Colors.BLACK,
            margin=ft.Margin.only(top=10),
            border_radius=20,
            border=ft.Border.all(1, ft.Colors.LIGHT_BLUE_100),
            padding=ft.Padding.only(top=40, left=30, right=30, bottom=40),
            content=ft.Column([
                ft.ResponsiveRow([
                    ft.TextField(label="Name", border_color=ft.Colors.GREY_700, col={"xs": 12, "sm": 6}),
                    ft.TextField(label="Email", border_color=ft.Colors.GREY_700, col={"xs": 12, "sm": 6}),
                ], run_spacing=20),
                ft.ResponsiveRow([
                    ft.TextField(label="Message", multiline=True, min_lines=8, max_lines=12, border_color=ft.Colors.GREY_700, col={"xs": 12}),
                ]),
                ft.Row([
                    ft.Button("SEND", width=200, height=50, style=ft.ButtonStyle(bgcolor=ft.Colors.BLUE_ACCENT, color=ft.Colors.WHITE, shape=ft.RoundedRectangleBorder(radius=10)))
                ], alignment=ft.MainAxisAlignment.END)
            ], spacing=25)
        ),
        ft.Container(
            content=ft.Text(" CONTACT US ", size=14, weight="bold", color=ft.Colors.WHITE),
            bgcolor=ft.Colors.BLACK,
            padding=ft.Padding.symmetric(horizontal=10),
            left=40,
            top=0,
        ),
    ], margin=ft.Margin.only(top=40))

    # --- Footer UI ---
    footer = ft.Container(
        content=ft.Row(
            [
                ft.TextButton("SERVICES", data="SERVICES", on_click=show_dialog, style=ft.ButtonStyle(color=ft.Colors.BLUE_200)),
                ft.TextButton("ABOUT US", data="ABOUT US", on_click=show_dialog, style=ft.ButtonStyle(color=ft.Colors.BLUE_200)),
                ft.TextButton("CONTACT US", data="CONTACT US", on_click=show_dialog, style=ft.ButtonStyle(color=ft.Colors.BLUE_200)),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=40,
        ),
        bgcolor=ft.Colors.BLACK,
        padding=ft.Padding.only(top=40, bottom=60),
        width=float("inf"),
        border=ft.Border.only(top=ft.BorderSide(1, ft.Colors.WHITE24)), 
    )

    # --- Assemble Layout ---
    mission_container = create_section_container("THE CORE MISSION", mission_content)
    services_container = create_section_container("SERVICES", services_content)
    
    main_layout = ft.Column(
        [
            logo_frame,
            ft.Container(height=20),
            mission_container,
            services_container,
            about_section,
            contact_section,
            ft.Container(expand=True), 
            footer,
        ], 
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=0,
        expand=True,
    )
    
    page.add(main_layout)
    page.update()

# --- Run App ---
ft.app(target=main, assets_dir="assets", view=ft.AppView.WEB_BROWSER)