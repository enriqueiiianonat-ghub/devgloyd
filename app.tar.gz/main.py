import flet as ft

def main(page: ft.Page):
    page.title = "DEVGLOYD"
    # 1. Switch to DARK mode
    page.theme_mode = ft.ThemeMode.DARK 
    # 2. Force background to pure black
    page.bgcolor = ft.Colors.BLACK 
    
    page.padding = 0
    page.spacing = 0
    page.scroll = ft.ScrollMode.ALWAYS

    email_ref = ft.Ref[ft.TextField]()
    msg_ref = ft.Ref[ft.TextField]()

    def send_inquiry(e):
        target_email = "enffdfdf@gmail.com" 
        user_email = email_ref.current.value
        user_msg = msg_ref.current.value
        subject = f"Website Inquiry from {user_email}"
        page.launch_url(f"mailto:{target_email}?subject={subject}&body={user_msg}")
        page.dialog.open = False
        page.update()

    def close_dlg(e):
        page.dialog.open = False
        page.update()

    def show_dialog(e):
        title_text = e.control.data
        if title_text == "CONTACT US":
            content = ft.Container(
                content=ft.Column([
                    ft.Text("Inquiry Form", size=20, weight="bold", color=ft.Colors.WHITE),
                    ft.TextField(ref=email_ref, label="Your Email", width=700),
                    ft.TextField(ref=msg_ref, label="Message", multiline=True, min_lines=5, width=700),
                    # Button kept white on dark background
                    ft.Button("Send Inquiry", bgcolor="#373e4e", color="white", on_click=send_inquiry)
                ], tight=True, spacing=10),
                width=800,
                padding=20
            )
        else:
            content = ft.Container(
                height=400,
                width=800,
                bgcolor=ft.Colors.BLACK, # Changed from #ededed
                border_radius=15,
                border=ft.Border.all(1, ft.Colors.WHITE), # Changed from #707070
                alignment=ft.alignment.Alignment(0, 0),
                content=ft.Text(f"Content for {title_text}", color=ft.Colors.WHITE),
            )
        dlg = ft.AlertDialog(
            title=ft.Text(title_text, color=ft.Colors.WHITE),
            content=content,
            actions=[ft.TextButton("Close", on_click=close_dlg)]
        )
        page.dialog = dlg
        page.overlay.append(dlg)
        dlg.open = True
        page.update()

    # --- Header UI ---
    logo_frame = ft.Container(
    # Use a Column to stack the video and the logo image
    content=ft.Column(
        controls=[
            # 1. The Video
            ft.Image(
                src="BLUE_EARTH.gif",
                height=350,
                fit="cover"
            ),
            
            # 2. The Logo Image
            ft.Image(
                src="LOGO_AI_TEXT.png", 
                width=400,        # Adjust width as needed
                fit="contain",
            ),
        ],
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        alignment=ft.MainAxisAlignment.CENTER,
        spacing=20, # Space between video and logo
    ),
    bgcolor=ft.Colors.BLACK,
    width=float("inf"),
    alignment=ft.alignment.Alignment.CENTER,
    padding=ft.Padding.only(left=20, top=50, right=20, bottom=40)
)
    #nav_row = ft.Row(
    #   [
    #       ft.TextButton("SERVICES", data="SERVICES", on_click=show_dialog),
    #       ft.TextButton("ABOUT US", data="ABOUT US", on_click=show_dialog),
    #       ft.TextButton("CONTACT US", data="CONTACT US", on_click=show_dialog),
    #    ],
    #    alignment=ft.MainAxisAlignment.CENTER,
    #   spacing=20,
     #)

# --- Services Section ---
        # --- Helper to maintain consistent styling across both containers ---
    def create_section_container(title, content_list):
        return ft.Stack([
            # The Main Box
            ft.Container(
                width=1000,
                bgcolor=ft.Colors.BLACK,
                margin=ft.Margin.only(top=10, bottom=20),
                border_radius=20,
                border=ft.Border.all(1, ft.Colors.LIGHT_BLUE_100),
                padding=ft.Padding.only(top=30, left=20, right=20, bottom=20),
                content=ft.Column(content_list, spacing=10)
            ),
            # The Floating Caption
            ft.Container(
                content=ft.Text(title, size=14, weight="bold", color=ft.Colors.WHITE),
                bgcolor=ft.Colors.BLACK,
                padding=ft.Padding.symmetric(horizontal=10),
                left=40,
                top=0,
            ),
        ])

    # --- 1. CORE MISSION CONTENT ---
    mission_content = [
        ft.ResponsiveRow([
            ft.Container(
                content=ft.Image(src="ABOUT.PNG", height=350, fit="contain"),
                col={"sm": 12, "md": 4},
            ),
            ft.Container(
                content=ft.Text(
                    spans=[
                        # Section 1: Intro Body
                        ft.TextSpan(
                            text=(
                                "We specialize in developing bespoke web solutions tailored to the unique "
                                "operational requirements of your business. In an era defined by rapid digital "
                                "acceleration, our mission is to bridge the gap between traditional business "
                                "models and the modern digital marketplace.\n\n"
                            ),
                            style=ft.TextStyle(color=ft.Colors.GREY_500)
                        ),
                        # Section 2: Header (White)
                        ft.TextSpan(
                            text="Adapting to the Digital Evolution\n\n",
                            style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD)
                        ),
                        # Section 3: Body
                        ft.TextSpan(
                            text=(
                                "The global commerce landscape is shifting toward a 'consumer-first' philosophy, "
                                "where comfort and convenience are the primary drivers of brand loyalty.\n\n"
                            ),
                            style=ft.TextStyle(color=ft.Colors.GREY_500)
                        ),
                        # Section 4: Header (White)
                        ft.TextSpan(
                            text="Strategic Automation & E-commerce\n\n",
                            style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD)
                        ),
                        # Section 5: Body
                        ft.TextSpan(
                            text="We empower enterprises to move beyond manual processes through advanced technological automation.",
                            style=ft.TextStyle(color=ft.Colors.GREY_500)
                        ),
                    ],
                    size=16,
                    text_align=ft.TextAlign.JUSTIFY
                ),
                col={"sm": 12, "md": 8},
                padding=10,
            ),
        ], vertical_alignment=ft.CrossAxisAlignment.CENTER)
    ]

    # --- 2. SERVICES CONTENT ---
    services_content = [
        # Item: Mobile Apps
        ft.ResponsiveRow([
            ft.Container(
                content=ft.Image(src="APPS.PNG", height=350, fit="contain"),
                col={"sm": 12, "md": 4},
            ),
            ft.Container(
                content=ft.Text(
                    spans=[
                        ft.TextSpan("Mobile Apps \n\n", style=ft.TextStyle(color=ft.Colors.WHITE, weight="bold")),
                        ft.TextSpan(
                            "Stop following the market and start leading it from your customers' pockets. "
                            "We specialize in custom mobile development that turns complex business requirements "
                            "into seamless user experiences.",
                            style=ft.TextStyle(color=ft.Colors.GREY_500)
                        ),
                    ],
                    size=16, text_align=ft.TextAlign.JUSTIFY
                ),
                col={"sm": 12, "md": 8}, padding=10,
            ),
        ], vertical_alignment=ft.CrossAxisAlignment.CENTER),
        
        ft.Divider(height=40, color=ft.Colors.GREY_800),

        # Item: Web & PWA
        ft.ResponsiveRow([
            ft.Container(
                content=ft.Image(src="WEB.PNG", height=350, fit="contain"),
                col={"sm": 12, "md": 4},
            ),
            ft.Container(
                content=ft.Text(
                    spans=[
                        ft.TextSpan("Web & Progressive Web Apps (PWA) \n\n", style=ft.TextStyle(color=ft.Colors.WHITE, weight="bold")),
                        ft.TextSpan(
                            "Why choose between a website and an app when you can have the best of both? "
                            "We transform the way businesses interact with the world by developing bespoke PWAs.",
                            style=ft.TextStyle(color=ft.Colors.GREY_500)
                        ),
                    ],
                    size=16, text_align=ft.TextAlign.JUSTIFY
                ),
                col={"sm": 12, "md": 8}, padding=10,
            ),
        ], vertical_alignment=ft.CrossAxisAlignment.CENTER),

        ft.Divider(height=40, color=ft.Colors.GREY_800),

        # Item: Desktop
        ft.ResponsiveRow([
            ft.Container(
                content=ft.Image(src="DESK.PNG", height=350, fit="contain"),
                col={"sm": 12, "md": 4},
            ),
            ft.Container(
                content=ft.Text(
                    spans=[
                        ft.TextSpan("Desktop \n\n", style=ft.TextStyle(color=ft.Colors.WHITE, weight="bold")),
                        ft.TextSpan(
                            "Why settle for limited web tools when you can command a high-performance desktop ecosystem? "
                            "We redefine enterprise efficiency by developing bespoke desktop applications.",
                            style=ft.TextStyle(color=ft.Colors.GREY_500)
                        ),
                    ],
                    size=16, text_align=ft.TextAlign.JUSTIFY
                ),
                col={"sm": 12, "md": 8}, padding=10,
            ),
        ], vertical_alignment=ft.CrossAxisAlignment.CENTER),
    ]

    # --- FINAL LAYOUT ---
    layout = ft.Column([
        create_section_container("THE CORE MISSION", mission_content),
        create_section_container("SERVICES", services_content),
    ], scroll=ft.ScrollMode.AUTO)


    # --- About Us Section ---
    # Created a reusable function for the placeholder pairs
    def placeholder_item(label, img_src):
        return ft.Column([
            # Actual Image from your assets folder
            ft.Container(
                width=100, 
                height=100, 
                border_radius=10,
                # Ensure US.png is the exact filename
                content=ft.Image(src=img_src, fit="US.PNG"), 
            ),
            # Text Placeholder
            ft.Column([
                ft.Text(f"{label}", weight="bold", color=ft.Colors.WHITE, size=14),
                ft.Text("Description placeholder text goes here.", 
                        color=ft.Colors.WHITE70, 
                        size=12, 
                        text_align=ft.TextAlign.CENTER),
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=5)
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER)

    about_section = ft.Stack([
        # 1. The Main Box with the Light Blue Border
        ft.Container(
            width=1000,
            bgcolor=ft.Colors.BLACK,
            margin=ft.Margin.only(top=10),
            border_radius=20,
            border=ft.Border.all(1, ft.Colors.LIGHT_BLUE_100), # The blue border
            padding=ft.Padding.only(top=40, left=20, right=20, bottom=40),
            content=ft.ResponsiveRow([
                ft.Container(content=placeholder_item("Team Member 1", "US.PNG"), col={"xs": 12, "sm": 4}),
                ft.Container(content=placeholder_item("Team Member 2", "US.PNG"), col={"xs": 12, "sm": 4}),
                ft.Container(content=placeholder_item("Team Member 3", "US.PNG"), col={"xs": 12, "sm": 4}),
            ], alignment=ft.MainAxisAlignment.CENTER, run_spacing=30)
        ), # <--- Correctly closing the Container

        # 2. The Caption located at the upper left of the border
        ft.Container(
            content=ft.Text(" ABOUT US ", size=14, weight="bold", color=ft.Colors.WHITE),
            bgcolor=ft.Colors.BLACK, # Matches background to "cut" the border line
            padding=ft.Padding.symmetric(horizontal=10),
            left=40,
            top=0,
        ),
    ], margin=ft.Margin.only(top=40)) # <--- ADD THIS LINE FOR THE SPACE

    # --- Contact Section ---
    # --- Contact Us Section ---
    # --- Contact Us Section ---
    contact_section = ft.Stack([
        ft.Container(
            width=1000,
            bgcolor=ft.Colors.BLACK,
            margin=ft.Margin.only(top=10),
            border_radius=20,
            border=ft.Border.all(1, ft.Colors.LIGHT_BLUE_100),
            padding=ft.Padding.only(top=40, left=30, right=30, bottom=40),
            content=ft.Column([
                # Name and Email Row
                ft.ResponsiveRow([
                    ft.TextField(
                        label="Name", 
                        border_color=ft.Colors.GREY_700, 
                        col={"xs": 12, "sm": 6}
                    ),
                    ft.TextField(
                        label="Email", 
                        border_color=ft.Colors.GREY_700, 
                        col={"xs": 12, "sm": 6}
                    ),
                ], run_spacing=20),
                
                # Message Field - Set to col=12 to make it full width (longer)
                ft.ResponsiveRow([
                    ft.TextField(
                        label="Message", 
                        multiline=True, 
                        min_lines=8, 
                        max_lines=12, 
                        border_color=ft.Colors.GREY_700,
                        col={"xs": 12} # This ensures it stretches across the red line area
                    ),
                ]),
                
                # Send Button
                ft.Row([
                    ft.Button(
                        "SEND", 
                        width=200, 
                        height=50,
                        style=ft.ButtonStyle(
                            bgcolor=ft.Colors.BLUE_ACCENT,
                            color=ft.Colors.WHITE,
                            shape=ft.RoundedRectangleBorder(radius=10),
                        )
                    )
                ], alignment=ft.MainAxisAlignment.END)
            ], spacing=25)
        ),

        # The Caption (Upper Left)
        ft.Container(
            content=ft.Text(" CONTACT US ", size=14, weight="bold", color=ft.Colors.WHITE),
            bgcolor=ft.Colors.BLACK,
            padding=ft.Padding.symmetric(horizontal=10),
            left=40,
            top=0,
        ),
    ], margin=ft.Margin.only(top=40))

    # --- Footer UI ---
    # --- Footer UI ---
    footer = ft.Container(
        content=ft.Row(
            [
                ft.TextButton(
                    "SERVICES", 
                    data="SERVICES", 
                    on_click=show_dialog,
                    style=ft.ButtonStyle(color=ft.Colors.BLUE_200) # Light blue matching your image
                ),
                ft.TextButton(
                    "ABOUT US", 
                    data="ABOUT US", 
                    on_click=show_dialog,
                    style=ft.ButtonStyle(color=ft.Colors.BLUE_200)
                ),
                ft.TextButton(
                    "CONTACT US", 
                    data="CONTACT US", 
                    on_click=show_dialog,
                    style=ft.ButtonStyle(color=ft.Colors.BLUE_200)
                ),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=40, # Adjusted spacing to match the image layout
        ),
        bgcolor=ft.Colors.BLACK,
        padding=ft.Padding.only(top=40, bottom=60), # Extra bottom padding for a cleaner look
        width=float("inf"),
        # White borderline at the top to separate footer
        border=ft.Border.only(top=ft.BorderSide(1, ft.Colors.WHITE24)), 
    )

    # 1. Define the separate containers first
    mission_container = create_section_container("THE CORE MISSION", mission_content)
    services_container = create_section_container("SERVICES", services_content)
    main_layout = ft.Column(
        [
            logo_frame,
           # nav_row,
            ft.Container(height=20),
            mission_container,    # Added the Mission container
            services_container,   # This replaces the old "services_section"
            about_section,
            contact_section,
            # Spacer to push footer down
            ft.Container(expand=True), 
            footer,
        ], 
        
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=0,
        expand=True, # Makes the column fill the entire page height
    )
        
    page.add(main_layout)
    page.update()

ft.app(target=main,assets_dir="assets", view=ft.AppView.WEB_BROWSER)