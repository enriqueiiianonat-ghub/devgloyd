import flet as ft
import requests

from products import PRODUCT_DESCRIPTIONS

def main(page: ft.Page):
    page.title = "DEVGLOYD"
    
    # 1. Switch to DARK mode
    page.theme_mode = ft.ThemeMode.DARK 
    # 2. Force background to pure black
    page.bgcolor = ft.Colors.BLACK 
    
    # --- ADD THIS LINE FOR THE ICON ---
    # This looks for "favicon.png" inside your /assets folder
    page.window_icon = "favicon.png" 
    
    page.padding = 0
    page.spacing = 0
    page.scroll = ft.ScrollMode.ALWAYS

    # --- References for the Form ---
    email_ref = ft.Ref[ft.TextField]()
    msg_ref = ft.Ref[ft.TextField]()
    selected_products = set()

    # --- Form Logic ---
    import httpx

    # 2. Checkout Logic
    def handle_checkout(e):
        if not selected_products:
            snack = ft.SnackBar(
                content=ft.Text("Please select at least one product!"), 
                bgcolor=ft.Colors.ORANGE_700
            )
            page.overlay.append(snack)
            snack.open = True
        else:
            # Create a summary of items
            items = ", ".join(selected_products)
            snack = ft.SnackBar(
                content=ft.Text(f"Proceeding with: {items}"), 
                bgcolor=ft.Colors.BLUE_700
            )
            page.overlay.append(snack)
            snack.open = True
        
        page.update()

    async def send_inquiry(e):
        user_email = email_ref.current.value 
        user_msg = msg_ref.current.value

        if not user_email or not user_msg:
            snack = ft.SnackBar(
                content=ft.Text("Please fill in all fields"),
                bgcolor=ft.Colors.ORANGE_700
            )
            page.overlay.append(snack)
            snack.open = True
            page.update()
            return

        payload = {
            "email": user_email,
            "message": user_msg
        }

        try:
            async with httpx.AsyncClient() as client:
                r = await client.post(
                    "https://formspree.io/f/xzdywdzv",
                    json={
                        "email": user_email,
                        "message": user_msg
                    },
                    headers={"Accept": "application/json"}
                )

            if r.status_code == 200:
                snack = ft.SnackBar(
                    content=ft.Text("Email sent successfully!"),
                    bgcolor=ft.Colors.GREEN_700
                )
                email_ref.current.value = ""
                msg_ref.current.value = ""
            else:
                snack = ft.SnackBar(
                    content=ft.Text(f"Failed: {r.status_code}"),
                    bgcolor=ft.Colors.RED_700
                )

        except Exception as ex:
            snack = ft.SnackBar(
                content=ft.Text("Network error."),
                bgcolor=ft.Colors.RED_700
            )

        page.overlay.append(snack)
        snack.open = True
        page.update()

    def close_dlg(e):
        page.dialog.open = False
        page.update()

  


    def show_dialog(e):
        title_text = e.control.data
        initial_message = ""

        # Check if the click came from a specific product inquiry
        if title_text.startswith("INQUIRY:"):
            product_name = title_text.split(":")[1]
            title_text = "CONTACT US" # Set title back to CONTACT US for the UI
            initial_message = f"Subject: Inquiry regarding {product_name}\n\nI would like to know more about..."

        if title_text == "CONTACT US":
            content = ft.Container(
                content=ft.Column([
                    ft.TextField(ref=email_ref, label="Your Email", width=700, bgcolor=ft.Colors.BLACK),
                    ft.TextField(
                        ref=msg_ref, 
                        label="Message", 
                        value=initial_message, # This puts the text inside the box
                        multiline=True, 
                        min_lines=5, 
                        width=700, 
                        bgcolor=ft.Colors.BLACK
                    ),
                    ft.Button("Send Inquiry", bgcolor="#373e4e", color="white", on_click=send_inquiry)
                ], tight=True, spacing=10),
                width=800,
                padding=5
            )
        else:
            # Your existing logic for SERVICES, ABOUT US, etc.
            content = ft.Container(
                height=400,
                width=800,
                bgcolor=ft.Colors.BLACK,
                border_radius=15,
                border=ft.Border.all(1, ft.Colors.WHITE),
                alignment=ft.alignment.Alignment.CENTER,
                content=ft.Text(f"Content for {title_text}", color=ft.Colors.WHITE),
            )

        dlg = ft.AlertDialog(
            title=ft.Text(title_text, color=ft.Colors.WHITE),
            content=content,
            actions=[ft.TextButton("Close", on_click=close_dlg)]
        )
        
        page.dialog = dlg
        page.overlay.append(dlg)
        dlg.open = True
        page.update()

    # --- UI Helpers ---
    def create_section_container(title, content_list):
        return ft.Stack([
            ft.Container(
                width=1000,
                bgcolor=ft.Colors.BLACK,
                margin=ft.Margin.only(top=10, bottom=20),
                border_radius=20,
                border=ft.Border.all(1, ft.Colors.LIGHT_BLUE_100),
                padding=ft.Padding.only(top=30, left=20, right=20, bottom=20),
                content=ft.Column(content_list, spacing=10)
            ),
            ft.Container(
                content=ft.Text(title, size=14, weight="bold", color=ft.Colors.WHITE),
                bgcolor=ft.Colors.BLACK,
                padding=ft.Padding.symmetric(horizontal=10),
                left=40,
                top=0,
            ),
        ])

    def placeholder_item(label, img_src):
        return ft.Column([
            ft.Container(
                width=100, 
                height=100, 
                border_radius=10,
                content=ft.Image(src=img_src, fit="contain"), 
            ),
            ft.Column([
                ft.Text(f"{label}", weight="bold", color=ft.Colors.WHITE, size=14),
                ft.Text("Description placeholder text goes here.", 
                        color=ft.Colors.WHITE70, 
                        size=12, 
                        text_align=ft.TextAlign.CENTER),
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=5)
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER)

    # --- Header UI ---
    logo_frame = ft.Container(
        content=ft.Column(
            controls=[
                ft.Image(src="BLUE_EARTH.gif", height=350, fit="cover"),
                ft.Image(src="LOGO_AI_TEXT.png", width=400, fit="contain"),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=20,
        ),
        bgcolor=ft.Colors.BLACK,
        width=float("inf"),
        alignment=ft.alignment.Alignment.CENTER,
        padding=ft.Padding.only(left=20, top=50, right=20, bottom=40)
    )

    # --- Core Mission Content ---
    mission_content = [
        ft.ResponsiveRow([
            ft.Container(
                content=ft.Image(src="ABOUT.PNG", height=350, fit="contain"),
                col={"sm": 12, "md": 4},
            ),
            ft.Container(
                content=ft.Text(
                    spans=[
                        # Main Header
                        ft.TextSpan(
                            text="Empowering Efficiency through Innovation\n",
                            style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD, size=20)
                        ),
                        ft.TextSpan(
                            text="At our core, we specialize in the development of sophisticated ",
                            style=ft.TextStyle(color=ft.Colors.GREY_500)
                        ),
                        ft.TextSpan(
                            text="data and human capital management systems",
                            style=ft.TextStyle(color=ft.Colors.GREY_500, weight=ft.FontWeight.BOLD)
                        ),
                        ft.TextSpan(
                            text=" designed to catalyze business efficacy and peak productivity. We believe that robust data architecture is a fundamental necessity for navigating the complexities of a modern economy.\n\n",
                            style=ft.TextStyle(color=ft.Colors.GREY_500)
                        ),

                        # Section 1
                        ft.TextSpan(
                            text="Strategic Data Intelligence\n",
                            style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD)
                        ),
                        ft.TextSpan(
                            text="In an era of rapid digital acceleration, the ability to monitor and analyze real-time data is critical. We provide the tools necessary to:\n",
                            style=ft.TextStyle(color=ft.Colors.GREY_500)#, weight=ft.FontWeight.BOLD)
                        ),
                        ft.TextSpan(
                            text="• Position your enterprise ",
                            style=ft.TextStyle(color=ft.Colors.GREY_500)
                        ),
                        ft.TextSpan(
                            text="strategically",
                            style=ft.TextStyle(color=ft.Colors.GREY_500, weight=ft.FontWeight.BOLD)
                        ),
                        ft.TextSpan(
                            text=" within the current market.\n• ",
                            style=ft.TextStyle(color=ft.Colors.GREY_500)
                        ),
                        ft.TextSpan(
                            text="Future-proof",
                            style=ft.TextStyle(color=ft.Colors.GREY_500, weight=ft.FontWeight.BOLD)
                        ),
                        ft.TextSpan(
                            text=" operations against evolving technological challenges.\n• Synthesize complex metrics into ",
                            style=ft.TextStyle(color=ft.Colors.GREY_500)
                        ),
                        ft.TextSpan(
                            text="actionable business intelligence.\n\n",
                            style=ft.TextStyle(color=ft.Colors.GREY_500, weight=ft.FontWeight.BOLD)
                        ),

                        # Section 2
                        ft.TextSpan(
                            text="Comprehensive Software Ecosystems\n",
                            style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD)
                        ),
                        ft.TextSpan(
                            text="We have perfected a multidisciplinary approach to software engineering, delivering high-performance, bespoke solutions across all primary platforms:\n",
                            style=ft.TextStyle(color=ft.Colors.GREY_500)
                        ),
                        ft.TextSpan(
                            text="• Web Applications: ",
                            style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.W_600)
                        ),
                        ft.TextSpan(
                            text="Scalable, cloud-based environments.\n",
                            style=ft.TextStyle(color=ft.Colors.GREY_500)
                        ),
                        ft.TextSpan(
                            text="• Mobile Solutions: ",
                            style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.W_600)
                        ),
                        ft.TextSpan(
                            text="On-the-go operational control.\n",
                            style=ft.TextStyle(color=ft.Colors.GREY_500)
                        ),
                        ft.TextSpan(
                            text="• Desktop Software: ",
                            style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.W_600)
                        ),
                        ft.TextSpan(
                            text="Powerful tools for specialized operations.\n\n",
                            style=ft.TextStyle(color=ft.Colors.GREY_500)
                        ),

                        # Section 3
                        ft.TextSpan(
                            text="Bridging the Digital Divide\n",
                            style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD)
                        ),
                        ft.TextSpan(
                            text="Our mission is to serve as the definitive bridge between traditional business models and the modern digital marketplace. By transforming legacy processes into streamlined, automated, and data-driven systems, we ensure our partners do not just keep pace with the industry—they lead it.",
                            style=ft.TextStyle(color=ft.Colors.GREY_500)
                        ),
                        
                    ],
                    size=16,
                    text_align=ft.TextAlign.JUSTIFY
                ),
                
                col={"sm": 12, "md": 8},
                padding=10,
            ),
        ], vertical_alignment=ft.CrossAxisAlignment.CENTER)
    ]

    # --- Services Content ---
    services_content = [
        # --- WEB-BASED ECOSYSTEMS ---
        ft.ResponsiveRow([
            ft.Container(
                content=ft.Image(src="WEB.PNG", height=350, fit="contain"),
                col={"sm": 12, "md": 4},
            ),
            ft.Container(
                content=ft.Text(
                    spans=[
                        ft.TextSpan("Web-Based Ecosystems\n\n", 
                                    style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD, size=18)),
                        ft.TextSpan("To thrive in a data-centric economy, your infrastructure must be as agile as your vision. We provide a full-stack ecosystem of digital tools designed to centralize control, automate repetitive tasks, and turn raw data into a competitive advantage.\n\n", 
                                    style=ft.TextStyle(color=ft.Colors.GREY_500)),
                        ft.TextSpan("Custom CRM & Data Management Platforms:\n", 
                                    style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD)),
                        ft.TextSpan("We build scalable, cloud-resident web applications that serve as the 'brain' of your operation.\n\n", 
                                    style=ft.TextStyle(color=ft.Colors.GREY_500)),
                        ft.TextSpan("• Centralized CRM: ", style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD)),
                        ft.TextSpan("Manage the entire customer lifecycle within a unified interface.\n", style=ft.TextStyle(color=ft.Colors.GREY_500)),
                        ft.TextSpan("• Dynamic Data Management: ", style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD)),
                        ft.TextSpan("Implement robust database architectures for real-time secure storage.\n", style=ft.TextStyle(color=ft.Colors.GREY_500)),
                        ft.TextSpan("• Workflow Automation: ", style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD)),
                        ft.TextSpan("Reduce human error by automating administrative tasks.", style=ft.TextStyle(color=ft.Colors.GREY_500)),
                    ],
                    size=16, text_align=ft.TextAlign.JUSTIFY
                ),
                col={"sm": 12, "md": 8}, padding=10,
            ),
        ], vertical_alignment=ft.CrossAxisAlignment.CENTER),

        ft.Divider(height=40, color=ft.Colors.GREY_800),

        # --- MOBILE SOLUTIONS ---
        ft.ResponsiveRow([
            ft.Container(
                content=ft.Image(src="APPS.PNG", height=350, fit="contain"),
                col={"sm": 12, "md": 4},
            ),
            ft.Container(
                content=ft.Text(
                    spans=[
                        ft.TextSpan("Mobile Solutions\n", 
                                    style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD, size=18)),
                        ft.TextSpan("Operational Control for the Decentralized Workforce\n\n", 
                                    style=ft.TextStyle(color=ft.Colors.GREY_400, italic=True)),
                        ft.TextSpan("In the modern business landscape, the office is wherever your team happens to be. Our mobile applications extend the power of your data management system to the palm of your hand.\n\n", 
                                    style=ft.TextStyle(color=ft.Colors.GREY_500)),
                        ft.TextSpan("• Real-Time Synchronization: ", style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD)),
                        ft.TextSpan("Field agents can input data and access critical files that sync instantly.\n", style=ft.TextStyle(color=ft.Colors.GREY_500)),
                        ft.TextSpan("• Personnel Monitoring & Management: ", style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD)),
                        ft.TextSpan("Track attendance and geographic progress for decentralized teams.\n", style=ft.TextStyle(color=ft.Colors.GREY_500)),
                        ft.TextSpan("• On-the-Go Analytics: ", style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD)),
                        ft.TextSpan("Access performance dashboards via mobile-optimized interfaces.", style=ft.TextStyle(color=ft.Colors.GREY_500)),
                    ],
                    size=16, text_align=ft.TextAlign.JUSTIFY
                ),
                col={"sm": 12, "md": 8}, padding=10,
            ),
        ], vertical_alignment=ft.CrossAxisAlignment.CENTER),

        ft.Divider(height=40, color=ft.Colors.GREY_800),

        # --- DESKTOP SOFTWARE ---
        ft.ResponsiveRow([
            ft.Container(
                content=ft.Image(src="DESK.PNG", height=350, fit="contain"),
                col={"sm": 12, "md": 4},
            ),
            ft.Container(
                content=ft.Text(
                    spans=[
                        ft.TextSpan("Desktop Software\n", 
                                    style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD, size=18)),
                        ft.TextSpan("High-Performance Tools for Specialized Internal Operations\n\n", 
                                    style=ft.TextStyle(color=ft.Colors.GREY_400, italic=True)),
                        ft.TextSpan("For tasks that require maximum processing power and offline reliability, we develop resource-intensive desktop applications tailored for deep-focus operations.\n\n", 
                                    style=ft.TextStyle(color=ft.Colors.GREY_500)),
                        ft.TextSpan("• Heavy-Duty Data Processing: ", style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD)),
                        ft.TextSpan("Optimized for complex calculations and large-scale data modeling.\n", style=ft.TextStyle(color=ft.Colors.GREY_500)),
                        ft.TextSpan("• Local Infrastructure Integration: ", style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD)),
                        ft.TextSpan("Seamlessly connect with on-site hardware and specialized peripherals.\n", style=ft.TextStyle(color=ft.Colors.GREY_500)),
                        ft.TextSpan("• Advanced Resource Management: ", style=ft.TextStyle(color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD)),
                        ft.TextSpan("Designed for power users who require multi-window capabilities and deep OS integration.", style=ft.TextStyle(color=ft.Colors.GREY_500)),
                    ],
                    size=16, text_align=ft.TextAlign.JUSTIFY
                ),
                col={"sm": 12, "md": 8}, padding=10,
            ),
        ], vertical_alignment=ft.CrossAxisAlignment.CENTER),
    ]

    # --- About Us Section ---
    about_section = ft.Stack([
        ft.Container(
            width=1000,
            bgcolor=ft.Colors.BLACK,
            margin=ft.Margin.only(top=10),
            border_radius=20,
            border=ft.Border.all(1, ft.Colors.LIGHT_BLUE_100),
            padding=ft.Padding.only(top=40, left=20, right=20, bottom=40),
            content=ft.ResponsiveRow([
                ft.Container(content=placeholder_item("QRIDME", "US.PNG"), col={"xs": 12, "sm": 4}),
                ft.Container(content=placeholder_item("RoulinPost", "US.PNG"), col={"xs": 12, "sm": 4}),
                ft.Container(content=placeholder_item("MuMeet", "US.PNG"), col={"xs": 12, "sm": 4}),
            ], alignment=ft.MainAxisAlignment.CENTER, run_spacing=30)
        ),
        ft.Container(
            content=ft.Text(" WORKS ", size=14, weight="bold", color=ft.Colors.WHITE),
            bgcolor=ft.Colors.BLACK,
            padding=ft.Padding.symmetric(horizontal=10),
            left=40,
            top=0,
        ),
    ], margin=ft.Margin.only(top=40, bottom=100))

        # --- Contact Us Section ---
    contact_section = ft.Stack([
        ft.Container(
            width=1000,
            bgcolor=ft.Colors.BLACK,
            margin=ft.Margin.only(top=10),
            border_radius=20,
            border=ft.Border.all(1, ft.Colors.LIGHT_BLUE_100),
            padding=ft.Padding.only(top=40, left=30, right=30, bottom=40),
            content=ft.Column([
                # Name and Email Row
                ft.ResponsiveRow([
                    #ft.TextField(
                        # If you create a name_ref = ft.Ref[ft.TextField]() at the top, add it here:
                        # ref=name_ref, 
                    #    label="Name", 
                     #   border_color=ft.Colors.GREY_700, 
                     #   col={"xs": 12, "sm": 6}
                    #),
                    ft.TextField(
                        ref=email_ref, # <--- Connects to your email_ref variable
                        label="Email", 
                        border_color=ft.Colors.GREY_700, 
                        col={"xs": 12, "sm": 6}
                    ),
                ], run_spacing=20),
                
                # Message Field
                ft.ResponsiveRow([
                    ft.TextField(
                        ref=msg_ref,   # <--- Connects to your msg_ref variable
                        label="Message", 
                        multiline=True, 
                        min_lines=8, 
                        max_lines=12, 
                        border_color=ft.Colors.GREY_700, 
                        col={"xs": 12}
                    ),
                ]),
                
                # Send Button
                ft.Row([
                    ft.Button(
                        "SEND", 
                        width=200, 
                        height=50,
                        # MOVE on_click HERE (Directly on the button)
                        on_click=send_inquiry, 
                        style=ft.ButtonStyle(
                            bgcolor=ft.Colors.BLUE_ACCENT, 
                            color=ft.Colors.WHITE, 
                            shape=ft.RoundedRectangleBorder(radius=10)
                        )
                    )
                ], alignment=ft.MainAxisAlignment.END)
            ], spacing=25)
        ),
        # The Caption
        ft.Container(
            content=ft.Text(" CONTACT US ", size=14, weight="bold", color=ft.Colors.WHITE),
            bgcolor=ft.Colors.BLACK,
            padding=ft.Padding.symmetric(horizontal=10),
            left=40,
            top=0,
        ),
    ], margin=ft.Margin.only(top=40,))


    # --- Shop Section ---
    # --- Function to handle the Product Dialog ---
    def open_product_details(e, name):
        # It now pulls from the imported dictionary
        details_text = PRODUCT_DESCRIPTIONS.get(
            name, 
            "No detailed description available."
        )

        def close_dlg(e):
            details_dlg.open = False
            page.update()

        details_dlg = ft.AlertDialog(
            bgcolor=ft.Colors.GREY_900,
            shape=ft.RoundedRectangleBorder(radius=15),
            title=ft.Text(name, color=ft.Colors.LIGHT_BLUE_100),
            content=ft.Text(details_text, color=ft.Colors.WHITE, size=14),
            actions=[
                ft.TextButton("CLOSE", on_click=close_dlg, style=ft.ButtonStyle(color=ft.Colors.LIGHT_BLUE_100)),
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        )

        page.overlay.append(details_dlg)
        details_dlg.open = True
        page.update()

    # --- Updated Helper function for Shop Items ---
    # --- Updated Helper function for Shop Items ---
    def create_shop_item(name, img_name):
        def on_toggle_select(e):
            if e.control.value:
                selected_products.add(name)
            else:
                selected_products.discard(name)
            print(f"Current Selection: {selected_products}")

        return ft.Container(
            col={"xs": 12, "md": 4},
            padding=15,
            border=ft.Border.all(1, ft.Colors.GREY_900),
            border_radius=10,
            content=ft.Column([
                # Clickable Icon/Image Container
                ft.Container(
                    height=140, 
                    bgcolor=ft.Colors.GREY_900, 
                    border_radius=8, 
                    alignment=ft.alignment.Alignment.CENTER, 
                    on_click=lambda e: open_product_details(e, name),
                    content=ft.Image(
                        src=img_name, 
                        width=80, 
                        height=80, 
                        fit="contain"  # <--- FIX: Used string instead of ft.ImageFit
                    )
                ),
                # Checkbox + Name Row
                ft.Row([
                    ft.Checkbox(
                        value=False,
                        fill_color=ft.Colors.LIGHT_BLUE_200,
                        on_change=on_toggle_select 
                    ),
                    ft.Text(name, size=18, weight="bold", color=ft.Colors.WHITE),
                ]),
                # Inquiry Button
                ft.OutlinedButton(
                    "Contact Us / Inquiry", 
                    icon=ft.Icons.MAIL_OUTLINED, 
                    style=ft.ButtonStyle(color=ft.Colors.LIGHT_BLUE_100), 
                    width=float("inf"),
                    data=f"INQUIRY:{name}", 
                    on_click=show_dialog
                ),
            ], spacing=10)
        )

    # --- Shop Section (Remains the same structure) ---
    # --- Shop Section ---
    shop_section = ft.Stack([
        ft.Container(
            width=1000,
            bgcolor=ft.Colors.BLACK,
            margin=ft.Margin.only(top=10),
            border_radius=20,
            border=ft.Border.all(1, ft.Colors.LIGHT_BLUE_100),
            padding=ft.Padding.only(top=40, left=30, right=30, bottom=40),
            content=ft.Column([
                # --- CATEGORY: WEB ---
                ft.Text("WEB APPLICATIONS", size=20, weight="bold", color=ft.Colors.LIGHT_BLUE_100),
                ft.ResponsiveRow([
                    # Pass the filename of your icon in the assets folder
                    create_shop_item("Web Starter", "web_start.png"),
                    create_shop_item("Web Professional", "web_pro.png"),
                    create_shop_item("Web Enterprise", "web_ent.png"),
                ], spacing=20, run_spacing=20),

                ft.Divider(height=40, color=ft.Colors.GREY_800),

                # --- CATEGORY: MOBILE APPS ---
                ft.Text("MOBILE APPS", size=20, weight="bold", color=ft.Colors.LIGHT_BLUE_100),
                ft.ResponsiveRow([
                    create_shop_item("iOS App", "ios_app.png"),
                    create_shop_item("Android App", "android_app.png"),
                    create_shop_item("Cross-Platform", "cross_flat.png"),
                ], spacing=20, run_spacing=20),

                ft.Divider(height=40, color=ft.Colors.GREY_800),

                # --- CATEGORY: DESKTOP ---
                ft.Text("DESKTOP SOFTWARE", size=20, weight="bold", color=ft.Colors.LIGHT_BLUE_100),
                ft.ResponsiveRow([
                    create_shop_item("Windows Suite", "win_app.png"),
                    create_shop_item("macOS Tool","mac_os.png"),
                    create_shop_item("Linux Client", "linux_os.png"),
                ], spacing=20, run_spacing=20),

                # --- MOVED INSIDE: FINAL CHECKOUT BUTTON ---
                ft.Divider(height=60, color=ft.Colors.TRANSPARENT),
                ft.Container(
                    alignment=ft.alignment.Alignment.CENTER,
                    content=ft.ElevatedButton(
                        "PROCEED TO CHECKOUT AND PAY", 
                        icon=ft.Icons.PAYMENT, 
                        bgcolor=ft.Colors.LIGHT_BLUE_200, 
                        color=ft.Colors.BLACK, 
                        width=400,
                        height=50,
                        on_click=handle_checkout, 
                        style=ft.ButtonStyle(
                            shape=ft.RoundedRectangleBorder(radius=10),
                            text_style=ft.TextStyle(weight=ft.FontWeight.BOLD) 
                        )
                    )
                )
            ], spacing=15)
        ),
        # Label Badge
        ft.Container(
            content=ft.Text(" SHOP ", size=14, weight="bold", color=ft.Colors.WHITE),
            bgcolor=ft.Colors.BLACK,
            padding=ft.Padding.symmetric(horizontal=10),
            left=40, top=0,
        ),
    ], margin=ft.Margin.only(top=40, bottom=40))
    

    # --- Footer UI ---
    footer = ft.Container(
        content=ft.Row(
            [
                ft.TextButton("SERVICES", data="SERVICES", on_click=show_dialog, style=ft.ButtonStyle(color=ft.Colors.BLUE_200)),
                ft.TextButton("ABOUT US", data="ABOUT US", on_click=show_dialog, style=ft.ButtonStyle(color=ft.Colors.BLUE_200)),
                ft.TextButton("CONTACT US", data="CONTACT US", on_click=show_dialog, style=ft.ButtonStyle(color=ft.Colors.BLUE_200)),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=40,
        ),
        bgcolor=ft.Colors.BLACK,
        padding=ft.Padding.only(top=40, bottom=60),
        width=float("inf"),
        border=ft.Border.only(top=ft.BorderSide(1, ft.Colors.WHITE24)), 
    )

    # --- Assemble Layout ---
    mission_container = create_section_container("THE CORE MISSION", mission_content)
    services_container = create_section_container("SERVICES", services_content)
    
    main_layout = ft.Column(
        [
            logo_frame,
            ft.Container(height=20),
            mission_container,
            services_container,
            shop_section,
            contact_section,
            about_section,
            ft.Container(expand=True), 
            footer,
        ], 
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=0,
        scroll=ft.ScrollMode.ADAPTIVE, # Enabled scrolling for the whole page
    )
    
    page.add(main_layout)
    page.update()

# --- Run App ---
ft.app(target=main, assets_dir="assets", view=ft.AppView.WEB_BROWSER)