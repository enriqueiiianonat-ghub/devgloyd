# products.py

PRODUCT_DESCRIPTIONS = {
    "Web Starter": "Perfect for small businesses. Includes a landing page and basic SEO.",
    "Web Professional": "Advanced e-commerce capabilities with custom API integrations.",
    "Web Enterprise": "Full-scale cloud infrastructure with 99.9% uptime SLA.",
    "iOS App": "Native Swift development optimized for the latest iPhone models.",
    "Android App": "Material Design focused app with support for a wide range of devices.",
    "Cross-Platform": "Single codebase using Flutter to reach both iOS and Android users.",
    "Windows Suite": "Powerful .NET desktop application for enterprise resource planning.",
    "macOS Tool": "SwiftUI based productivity tool designed for the Apple ecosystem.",
    "Linux Client": "Lightweight, high-performance binary for various distributions.",
}